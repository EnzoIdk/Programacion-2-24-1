/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   MuestraPunteros.h
 * Author: aml
 *
 * Created on 22 de abril de 2024, 10:23 AM
 */

#ifndef MUESTRAPUNTEROS_H
#define MUESTRAPUNTEROS_H

void imprimeProductos(void *prod);
void imprimirProd(void *prod);
void imprimeClientes(void *cli);
void imprimirCli(void *cli);
void imprimirPedidos(void *ped);
void imprimirPed(void *ped);

void imprimeReporte();

#endif /* MUESTRAPUNTEROS_H */

