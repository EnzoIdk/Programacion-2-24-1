/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funciones.h
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 25 de abril de 2024, 12:40
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

#include <fstream>
using namespace std;
void lecturaClientes( void *&cli);
void *obtenerClient(ifstream &arch);
char *lecturaExacta(ifstream &arch, char car);
void lecturaLibros(void *&li);
void *obtenerLibro(ifstream &arch);
//PEIDDOS
void lecturaPedidos(void *&ped, void*cli, void*&lib);
int buscarDni(int dni, ifstream &arch, void *cli);
bool comparaDNI(int dni, void *cli);
int buscarDni2(int dni, ifstream &arch, void **cli, int nd);
void *obtenerPedido(int dn, void *cli,void *&buffe);
void  lecturaPedidos(ifstream &arch,void *buffer,int  numPed, void *&lib);
void *obtenerLibro(void *lib, char*codigo, int numped);
int buscarLibro(char *codigo, void* lib);
bool comparaLibro(char *codigo,void*lib);
void *obtenerMiniLibro(char *codigo, char *nombre, int *stock);
//asginar memoria
void asignarMemoriaExacta( void *&firme, void *buffer );
void  asignarMemoriaListaPedidos(void *&firme, void *buffer,int numPedidos );
//impresion
void impresion(void *ped);
void imprimirPedidosClientes(void *ped,ofstream &arch);
void  impresionListaPedidos(void *ped, ofstream &arch);
void impresionRegLibro(void *ped, ofstream &arch);
void   impresionDatosLIbro(void *ped, ofstream &arch);
void linea(ofstream &arch, int cant, char sig);
#endif /* FUNCIONES_H */

