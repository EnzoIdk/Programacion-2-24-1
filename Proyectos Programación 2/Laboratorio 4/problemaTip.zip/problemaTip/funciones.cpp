/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "funciones.h"
#define MAX 100
void lecturaClientes( void *&cli){
    ifstream arch("cientes.csv", ios::in);
    if (not arch.is_open()){
        cout<<"error con el archivo de los clientes: "<<endl;
        exit(1);
    }
    void *reg;
    void*clientes[400]{};
    int nd=0;
    while(true){
        reg=obtenerClient(arch);
        if (arch.eof()) break;
        clientes[nd]=reg;
        nd++;
    }

    void **aux=new  void *[nd+1]{};
    for (int i = 0; i < nd; i++) {
        aux[i]=clientes[i];
    }
    cli=aux;

}
void *obtenerClient(ifstream &arch){
    int *dni=new int, dn;
    char *nombre;
    arch>>dn;
    arch.get();
    if (arch.eof()) return nullptr;;
    nombre=lecturaExacta(arch,'\n');
    *dni=dn;
    //crear registor
    void **registro=new void *[5]{};
    registro[0]=dni;
    registro[1]=nombre;
    registro[2]=nullptr;
    return registro;
}
char *lecturaExacta(ifstream &arch, char car){
    char *aux, nom[500]{};
    arch.getline(nom, 500, car);
    aux=new char [strlen(nom)+1]{};
    strcpy(aux, nom);
    return aux;
}
void lecturaLibros(void *&li){
     ifstream arch("libros .csv", ios::in);
    if (not arch.is_open()){
        cout<<"error con el archivo de los clientes: "<<endl;
        exit(1);
    }
//    IIM5175,Diamantes y pedernales,Jose Maria Arguedas,2,30.23
    void *reg;
    void *libros[400]{};
    int nd=0;
    while(true){
        reg=obtenerLibro(arch);
        if (arch.eof()) break;
        libros[nd]=reg;
        nd++;
    }
     void **aux=new  void *[nd+1]{};
    for (int i = 0; i < nd; i++) {
        aux[i]=libros[i];
    }
    li=aux;
}
void *obtenerLibro(ifstream &arch){
    char *codigo=lecturaExacta(arch,',');
    if (arch.eof()) return nullptr;;
    char *nombre=lecturaExacta(arch,',');
    char *autor=lecturaExacta(arch,',');
     int *stock=new int, st;
    double *precio=new double, pre;
    arch>>st;
    arch.get();
    arch>>pre;
    arch.get();
    *stock=st;
    *precio=pre;
   //crear registro
      void **registro=new void *[5]{};
    registro[0]=codigo;
    registro[1]=nombre;
    registro[2]=autor;
    registro[3]=stock;
    registro[4]=precio;
    return registro;
}
void lecturaPedidos(void *&ped, void*cli, void*&lib){
     ifstream arch("pedidos.txt", ios::in);
    if (not arch.is_open()){
        cout<<"error con el archivo de los clientes: "<<endl;
        exit(1);
    }
     int idDni,idPedCli,numPed, dni,nd=0;;
     void **cliente=(void**)cli, *reg,*buffer[499]{};;
     while(true){
         arch>>numPed;
         if(arch.eof()) break;
         arch.get();
         arch>>dni;
         arch.get();
         idDni=buscarDni(dni, arch, cli);
        idPedCli=buscarDni2(dni, arch, buffer, nd);
         if (idPedCli==-1){
             reg=obtenerPedido(dni, cliente[idDni],buffer[nd]);//en esta parte estoy obteniedo el arr2
             buffer[nd]=reg;
             lecturaPedidos(arch,buffer[nd], numPed, lib);
             nd++;
         }else{
             lecturaPedidos(arch,buffer[idPedCli], numPed, lib);
         }
     }
    void** pedidos=new void *[nd+1]{};
    for (int i = 0; i < nd; i++) {
        pedidos[i]=buffer[i];
        asignarMemoriaExacta( pedidos[i], buffer[i] );
    }
    ped=pedidos;
}
void asignarMemoriaExacta( void *&firme, void *buffer ){
    void**aux=(void**)firme;
    void**aux2=(void**)buffer;
    asignarMemoriaListaPedidos(aux[2], aux2[2], *(int*)aux2[3]);
//    cout<<*(int*)aux2[3]<<endl;
}
void  asignarMemoriaListaPedidos(void *&firme, void *buffer,int numPedidos ){
      void**aux=new void*[numPedidos+1]{};
      void**aux2=(void**)buffer;
    for (int i = 0; i < numPedidos; i++) {
        aux[i]=aux2[i];
    }
    delete aux2;
    firme=aux;
}
int buscarDni(int dni, ifstream &arch, void *cli){
    void **cliente=(void**)cli;
    for (int i = 0; cliente[i]; i++) {
        if (comparaDNI(dni, cliente[i])) return i;
    }
    return -1;

}
int buscarDni2(int dni, ifstream &arch, void **cli, int nd){
    for (int i = 0; i<nd; i++) {
        if (comparaDNI(dni, cli[i])) return i;
    }
    return -1;
}
bool comparaDNI(int dni, void *cli){
     void **cliente=(void**)cli;
     return*(int*)cliente[0]==dni;
}
void *obtenerPedido(int dn, void *cli,void *&buffe){
    int *dni=new int;
    *dni=dn;
    void **cliente=(void**)cli;
    char *nombre=(char*)cliente[1];
    char*nuevo=new char[strlen(nombre)+1]{};
    strcpy(nuevo, nombre);
    //registro
    void **registro=new void*[4]{};
    registro[0]=dni;
    registro[1]=nuevo;
    int *nd=new int;
    *nd=0;
    void **aux=(void**)registro[2];
    aux=new void*[100]{};//asigné memoria a cada lista de pedidos
    registro[2]=aux;
     registro[3]=nd;
    return registro;
}
void  lecturaPedidos(ifstream &arch,void *buffer,int  numPed, void *&lib){
    void **registroPedido=(void**)buffer;
    void **ListaPedidos=(void**)registroPedido[2];
    char codigo[8]{};
    int idLibro;
    int nd=*(int*)registroPedido[3];
    void **libros=(void**)lib;
    arch>>codigo;
     idLibro=buscarLibro(codigo, lib);
    ListaPedidos[nd]=obtenerLibro(libros[idLibro], codigo, numPed);
    *(int*)registroPedido[3]=*(int*)registroPedido[3]+1;
}
int buscarLibro(char *codigo, void* lib){
    void **libros=(void**)lib;
    for (int i = 0; libros[i]; i++) {
        if (comparaLibro(codigo, libros[i])) return i;
    }
    return -1;

}
bool comparaLibro(char *codigo,void*lib){
    void **libros=(void**)lib;
    return strcmp((char*)libros[0], codigo)==0;
}
void *obtenerLibro(void *lib, char*codigo, int numped){
    void **registroLibro=(void**)lib;
   double *precio=new double;
   *precio=*(double*)registroLibro[4];
     int*stock=new int;
     *stock=*(int*)registroLibro[3];
    char *cod=new char[strlen(codigo)+1]{};
    int *num=new int;
    *num=numped;
    strcpy(cod, codigo);
     void **registro=new void *[3]{};
    registro[0]=num;
    registro[1]=obtenerMiniLibro(cod, (char*)registroLibro[1], (int *)registroLibro[3]);
    registro[2]=precio;
    return registro;
}
void *obtenerMiniLibro(char *codigo, char *nombre, int *stock){
    void **registro=new void *[3]{};
    registro[0]=codigo;
    registro[1]=nombre;
    int atendido=0, *aten=new int;
    if ( *stock>0) {
        atendido=1; 
        *stock--;
    }
    *aten=atendido;
     registro[2]=aten;
     return registro;
}
void impresion(void *ped){
      ofstream arch("impresionFinal.txt", ios::out);
    if (not arch.is_open()){
        cout<<"error con el archivo de los clientes: "<<endl;
        exit(1);
    }
      void **pedidos=(void**)ped;
      arch<<setw((MAX+19)/2)<<"PEDIDOS POR CLIENTE"<<endl;
       linea(arch, MAX, '=');
    for (int i = 0; pedidos[i]; i++) {
        imprimirPedidosClientes(pedidos[i], arch);
    }
}
void imprimirPedidosClientes(void *ped,ofstream &arch){
     void **pedidos=(void**)ped;
     arch<<setw(5)<<"DNI"<<setw(50)<<"NOMBRE"<<endl;
      linea(arch, MAX, '-');
     arch<<setw(10)<<*(int*)pedidos[0]<<setw(60)<<right<<(char*)pedidos[1]<<endl;
     if (pedidos[2]!=nullptr)impresionListaPedidos(pedidos[2], arch);
     linea(arch, MAX, '=');
}
void  impresionListaPedidos(void *ped, ofstream &arch){
     void **pedidos=(void**)ped;
     arch<<setw(15)<<"CodPedido"<<setw(65)<<"Libro"<<setw(20)<<"Monto"<<endl;
    for (int i = 0; pedidos[i]; i++) {
        impresionRegLibro(pedidos[i], arch);
    }
}
void impresionRegLibro(void *ped, ofstream &arch){
     void **pedidos=(void**)ped;
     int pedidosnum=*(int*)pedidos[0];
     arch<<setw(6)<<' '<<setw(6)<<setfill('0')<<pedidosnum<<setfill(' ')<<endl;
     arch<<setw(5)<<' ';
     impresionDatosLIbro(pedidos[1],arch);
     arch<<setw(5)<<*(double*)pedidos[2]<<endl;
}
void   impresionDatosLIbro(void *ped, ofstream &arch){
     void **pedidos=(void**)ped;
     arch<<(char*)pedidos[0]<<setw(4)<<' '<<setw(60)<<right<<(char*)pedidos[1]<<setw(4)<<' ';
     if (*(int*)pedidos[2]==1){
         arch<<"Atendido"<<setw(5)<<' ';
     }else{
         arch<<"No atendido"<<setw(5)<<' ';
     }
}
void linea(ofstream &arch, int cant, char sig){
    for (int i = 0; i < cant; i++) {
        arch<<sig;
    }
    arch<<endl;

}