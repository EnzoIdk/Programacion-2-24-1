/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 25 de abril de 2024, 12:12
 */

#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    void *clientes;
    void*libros;
    void *pedidos;
    lecturaClientes(clientes);
    lecturaLibros(libros);
    lecturaPedidos(pedidos, clientes, libros);
    impresion(pedidos);
    return 0;
}

