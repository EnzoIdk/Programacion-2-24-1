/*
 *  Intento de Lucas Mattias Alvites Galarza - 20221943
 */

/* 
 * File:   Nodo.cpp
 * Author: Lucas
 * 
 * Created on 20 de junio de 2024, 21:15
 */

#include <iostream>
using namespace std;
#include <cstring>

#include "Nodo.h"

//CONSTRUCTOR, COPIA, DESTRUCTOR

Nodo::Nodo() {
    sig=nullptr;
}

Nodo::Nodo(const class Nodo &orig) {

}

Nodo::~Nodo() {
    
}

//GETTERS Y SETTERS


//METODOS


//FUNCIONES
