/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Noodo.h
 * Author: margo
 *
 * Created on 7 de julio de 2024, 13:22
 */

#ifndef NOODO_H
#define NOODO_H

class Noodo {
private:


public:
    Noodo();
    Noodo(const Noodo& orig);
    virtual ~Noodo();

};
#endif /* NOODO_H */

