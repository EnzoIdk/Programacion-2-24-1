class Principal{
	public static void main(String [] arg){
		Biblioteca bli;
		bli=new Biblioteca();
		bli.carga();
		bli.imprime();
	}
}