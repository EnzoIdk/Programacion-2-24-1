/*
 * Intento de Lucas Mattias Alvites Galarza - 20221943
 */

/* 
 * File:   main.cpp
 * Author: Lucas
 *
 * Created on 7 de julio de 2024, 06:26 PM
 */

#include "Programacion.h"

int main(int argc, char ** argv) {
    class Programacion pro;
    
    pro.cargavehiculos();
    pro.cargaprogramacion();
    
    pro.reducevehiculos(10);
    pro.muestraprogramacion();
    
    
    return 0;
}

