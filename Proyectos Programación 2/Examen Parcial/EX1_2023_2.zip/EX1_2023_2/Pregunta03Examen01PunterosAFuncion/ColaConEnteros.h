/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   ColaConEnteros.h
 * Author: Enzo
 *
 * Created on 8 de mayo de 2024, 02:02 PM
 */

#ifndef COLACONENTEROS_H
#define COLACONENTEROS_H

using namespace std;

void *leenumero(ifstream &arch);
void imprimenumero(ofstream &arch,void *dato);

#endif /* COLACONENTEROS_H */

