/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 13 de mayo de 2024, 07:22 PM
 */
#include "listaDoblementeEnlazadaGenerica.h"

int intcmp(const void *a,const void *b){
    int *ai=(int*)a,*bi=(int*)b;
    return *ai-*bi;
}

void imprimeInt(void *dato){
    int *num=(int*)dato;
    cout<<*num<<"->";
}

int main(int argc, char** argv) {
    void *listaD;
    crearlistaD(listaD);
    
    int *dato=new int,*dato1=new int;
    *dato=1;*dato1=2;
    
    insertar(listaD,dato);
    insertar(listaD,dato1);
    imprimir(listaD,imprimeInt);
    cout<<endl;
    eliminar(listaD,dato,intcmp);
    cout<<esListaDVacia(listaD)<<endl;
    cout<<tamanio(listaD)<<endl;
    destruir(listaD);
    cout<<esListaDVacia(listaD)<<endl;
    imprimir(listaD,imprimeInt);    
    return 0;
}

