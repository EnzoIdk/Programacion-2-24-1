/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "listaDoblementeEnlazadaGenerica.h"

enum listaD{CABEZA,COLA,LONGITUD};
enum nodo{DATO,ANTERIOR,SIGUIENTE};

void crearlistaD(void *&listaD){
    void **estructura_listaD=new void*[3]{};
    int *longitud=new int;
    *longitud=0;
    estructura_listaD[LONGITUD]=longitud;
    
    listaD=estructura_listaD;
}

bool esListaDVacia(const void *listaD){
    void **estructura_listaD=(void**)listaD;
    int *longitud=(int*)estructura_listaD[LONGITUD];
    return *longitud==0;
}

void insertar(void *&listaD,void *dato){//inserta al final
    void **estructura_listaD=(void**)listaD,**nodoNuevo=new void*[3]{},**nodoActual;
    
    nodoNuevo[DATO]=dato;
    
    if(esListaDVacia(listaD)){
        estructura_listaD[CABEZA]=nodoNuevo;
        estructura_listaD[COLA]=nodoNuevo;
    }else{
        nodoActual=(void**)estructura_listaD[COLA];
        nodoActual[SIGUIENTE]=nodoNuevo;
        nodoNuevo[ANTERIOR]=nodoActual;
        estructura_listaD[COLA]=nodoNuevo;
    }
    (*(int*)estructura_listaD[LONGITUD])++;
}

void eliminar(void *&listaD,void *dato,int (*cmp)(const void*,const void*)){//recorre desde la cabeza
    void **estructura_listaD=(void**)listaD,**nodoActual;
    
    nodoActual=(void**)estructura_listaD[CABEZA];
    while(nodoActual){
        void *datoBuscado=nodoActual[DATO];
        if(cmp(dato,datoBuscado)==0){//si dato - datoBuscado == 0 son iguales
            void **nodoAnterior=(void**)nodoActual[ANTERIOR];
            void **nodoSiguiente=(void**)nodoActual[SIGUIENTE];
            
            if(nodoAnterior==nullptr)//eliminar el primer nodo
                estructura_listaD[CABEZA]=nodoSiguiente;
            else if(nodoSiguiente==nullptr)//eliminas el ultimo nodo
                estructura_listaD[COLA]=nodoAnterior;
            else{
                nodoAnterior[SIGUIENTE]=nodoSiguiente;
                nodoSiguiente[ANTERIOR]=nodoAnterior;
            }
            delete nodoActual;
            (*(int*)estructura_listaD[LONGITUD])--;
            break;
        }
        nodoActual=(void**)nodoActual[SIGUIENTE];
    }
}

int tamanio(const void*listaD){
    void **estructura_listaD=(void**)listaD;
    int *longitud=(int*)estructura_listaD[LONGITUD];
    return *longitud;
}

void destruir(void *&listaD){//elimina desde la cabeza
    void **estructura_listaD=(void**)listaD,**nodoActual,**nodoSiguiente;
    
    nodoActual=(void**)estructura_listaD[CABEZA];
    while(not esListaDVacia(listaD)){
        nodoSiguiente=(void**)nodoActual[SIGUIENTE];
        
        delete nodoActual;
        
        nodoActual=nodoSiguiente;
        
        if(nodoSiguiente==nullptr){
            estructura_listaD[CABEZA]=nodoSiguiente;
            estructura_listaD[COLA]=nodoSiguiente;
        }
        (*(int*)estructura_listaD[LONGITUD])--;
    }
}

void imprimir(const void*listaD,void (*imprime)(void *)){//imprime desde la cabeza
    void **estructura_listaD=(void**)listaD,**nodoActual,*dato;
    
    if(esListaDVacia(listaD)){
        cout<<"La lista esta vacia"<<endl;
        return;
    }
    
    nodoActual=(void**)estructura_listaD[CABEZA];
    while(nodoActual){
        dato=nodoActual[DATO];
        imprime(dato);
        nodoActual=(void**)nodoActual[SIGUIENTE];
    }
}