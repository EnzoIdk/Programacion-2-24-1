/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   listaDoblementeEnlazadaGenerica.h
 * Author: Usuario
 *
 * Created on 13 de mayo de 2024, 07:36 PM
 */

#ifndef LISTADOBLEMENTEENLAZADAGENERICA_H
#define LISTADOBLEMENTEENLAZADAGENERICA_H

#include <iostream>

using namespace std;

void crearlistaD(void *&listaD);
bool esListaDVacia(const void *listaD);
void insertar(void *&listaD,void *dato);
void eliminar(void *&listaD,void *dato,int (*cmp)(const void*,const void*));
int tamanio(const void*listaD);
void destruir(void *&listaD);
void imprimir(const void*listaD,void (*imprime)(void *));

#endif /* LISTADOBLEMENTEENLAZADAGENERICA_H */

