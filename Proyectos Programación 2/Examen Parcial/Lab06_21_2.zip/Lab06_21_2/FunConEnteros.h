/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   FuncConEnteros.h
 * Author: Enzo
 *
 * Created on 14 de mayo de 2024, 12:15 AM
 */

#ifndef FUNCCONENTEROS_H
#define FUNCCONENTEROS_H

using namespace std;

void *leenumero(ifstream &arch);
int prioridadnumero(void *dato);
void muestranumero(ofstream &arch,void *dato,int i);

#endif /* FUNCCONENTEROS_H */

