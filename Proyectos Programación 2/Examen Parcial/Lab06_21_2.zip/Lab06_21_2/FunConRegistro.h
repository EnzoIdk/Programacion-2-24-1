/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   FunConRegistro.h
 * Author: Enzo
 *
 * Created on 14 de mayo de 2024, 12:16 AM
 */

#ifndef FUNCONREGISTRO_H
#define FUNCONREGISTRO_H



#endif /* FUNCONREGISTRO_H */

