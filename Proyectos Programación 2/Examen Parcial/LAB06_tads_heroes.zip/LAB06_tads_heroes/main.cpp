/* 
 * File:   LAB06_tads_heroes.cpp
 * Author: Crystallyzer
 *
 * Created on 3 de mayo de 2024, 12:25 AM
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>
#include <cstdlib>
#include "arreglos_genericos.h"
#include "listas_genericas.h"

using namespace std;

int main(int argc, char** argv) {
    void *arreglo_heroes,*lista_heroes;
    int cantidad_total_heroes;
    llenar_arreglo_heroes(arreglo_heroes,cantidad_total_heroes,"heroes_changelog_1223.csv");
    qsort(arreglo_heroes,cantidad_total_heroes,sizeof(void *),cmp_multicriterio_void);
    //imprimirArreglo(arreglo_heroes,cantidad_total_heroes);
    crear_lista_heroes(arreglo_heroes,lista_heroes,leer_heroe);
    imprimir_lista_heroes(lista_heroes,imprimir_registro_heroe);
    eliminar_lista_heroes_repetidos(lista_heroes,eliminar_registro);
    imprimir_lista_heroes(lista_heroes,imprimir_registro_heroe);
    
    return 0;
}