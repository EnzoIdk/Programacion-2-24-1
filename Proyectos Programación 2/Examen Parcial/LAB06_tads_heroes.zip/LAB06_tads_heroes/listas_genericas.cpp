/* 
 * File:   listas_genericas.cpp
 * Author: Crystallyzer
 *
 * Created on 3 de mayo de 2024, 01:55 AM
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>
#include <cstdlib>
#include "arreglos_genericos.h"
#include "listas_genericas.h"

#define NUM_LINEA 60

enum Heroe{CODIGO,NOMBRE,ROL,CATEGORIA,PUNTAJE};
enum Lista{DATO,SIG};

using namespace std;

void crear_lista_heroes(void *arreglo_heroes,void *&lista_heroes,void *(*leer)(void *,int)){
    void *dato;
    int i=0;
    
    lista_heroes=nullptr;
    while(1){
        dato=leer(arreglo_heroes,i);
        if(dato==nullptr)break;
        insertar_lista_final(lista_heroes,dato);
        i++;
    }
}

void *leer_heroe(void *arreglo_heroes,int i){
    void **heroe=(void **)arreglo_heroes;
    return heroe[i];
}

void insertar_lista_inicio(void *&lista_heroes,void *dato){
    void **p=(void **)lista_heroes,**nuevo;
    nuevo=new void *[2];
    nuevo[DATO]=dato;
    nuevo[SIG]=p;
    lista_heroes=nuevo;
}

void insertar_lista_final(void *&lista_heroes,void *dato){
    void **p=(void **)lista_heroes,**ant=nullptr,**nuevo;
    nuevo=new void *[2];
    nuevo[DATO]=dato;
    nuevo[SIG]=nullptr;
    while(p){
        ant=p;
        p=(void **)p[SIG];
    }
    if(ant==nullptr)lista_heroes=nuevo;
    else ant[SIG]=nuevo;
}

void imprimir_lista_heroes(void *lista_heroes,void (*imprimir)(ofstream &,void *)){
    void **p=(void **)lista_heroes;
    
    ofstream archReporte("Reporte-Heroes.txt",ios::out);
    if(!archReporte){
        cout<<"ERROR: no se pudo abrir el archivo Reporte-Heroes.txt"<<endl;
        exit(1);
    }
    
    archReporte<<left<<setw(16)<<"Nombre"<<setw(12)<<"Rol"<<setw(14)<<"Categoria"<<setw(12)<<"Puntaje"<<"Codigo"<<endl;
    imprimirLinea(archReporte,NUM_LINEA,'=');
    while(p){
        imprimir(archReporte,p[DATO]);
        p=(void **)p[SIG];
    }
}

void imprimir_registro_heroe(ofstream &arch,void *reg){
    void **registro=(void **)reg;
    char *nombre=(char *)registro[NOMBRE];
    char *rol=(char *)registro[ROL];
    char *categoria=(char *)registro[CATEGORIA];
    double *puntaje=(double *)registro[PUNTAJE];
    int *codigo=(int *)registro[CODIGO];
    
    arch<<left<<setw(16)<<nombre<<setw(14)<<rol<<setw(10)<<categoria<<right<<setw(8)<<*puntaje<<setw(12)<<*codigo<<endl;
}

void eliminar_lista_heroes_repetidos(void *&lista_heroes,void (*eliminar)(void *&)){
    void **p=(void **)lista_heroes,**ant=nullptr,**sig=nullptr;
    while(p[SIG]){
        ant=p;
        p=(void **)p[SIG];
        if(sonIguales(ant[DATO],p[DATO])){
            sig=(void **)p[SIG];
            eliminar(p[DATO]);
            delete p;
            ant[SIG]=sig;
            p=sig;
        }
    }
}

int sonIguales(void *datoA,void *datoB){
    void **anterior=(void **)datoA,**actual=(void **)datoB;
    char *nombreAnt=(char *)anterior[NOMBRE],*nombreAct=(char *)actual[NOMBRE];
    
    return strcmp(nombreAnt,nombreAct)==0;
}

void eliminar_registro(void *&reg){
    void **actual=(void **)reg;
    char *nombre=(char *)actual[NOMBRE];
    char *rol=(char *)actual[ROL];
    char *categoria=(char *)actual[CATEGORIA];
    double *puntaje=(double *)actual[PUNTAJE];
    int *codigo=(int *)actual[CODIGO];
    
    delete nombre;
    delete rol;
    delete categoria;
    delete puntaje;
    delete codigo;
}

void imprimirLinea(ofstream &arch,int cantidad,char simbolo){
    for(int i=0;i<cantidad;i++)arch<<simbolo;
    arch<<endl;
}