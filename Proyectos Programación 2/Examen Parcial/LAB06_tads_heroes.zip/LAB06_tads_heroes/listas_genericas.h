/* 
 * File:   listas_genericas.h
 * Author: Crystallyzer
 *
 * Created on 3 de mayo de 2024, 01:55 AM
 */

#ifndef LISTAS_GENERICAS_H
#define LISTAS_GENERICAS_H

#include <fstream>
using namespace std;

void crear_lista_heroes(void *,void *&,void *(*)(void *,int));
void *leer_heroe(void *,int);
void insertar_lista_inicio(void *&,void *);
void insertar_lista_final(void *&,void *);
void imprimir_lista_heroes(void *,void (*)(ofstream &,void *));
void imprimir_registro_heroe(ofstream &,void *);
void eliminar_lista_heroes_repetidos(void *&,void (*)(void *&));
int sonIguales(void *,void *);
void eliminar_registro(void *&);
void imprimirLinea(ofstream &,int,char);

#endif /* LISTAS_GENERICAS_H */