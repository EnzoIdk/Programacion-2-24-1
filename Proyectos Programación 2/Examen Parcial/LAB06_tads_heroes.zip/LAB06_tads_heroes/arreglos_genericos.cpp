/* 
 * File:   arreglos_genericos.cpp
 * Author: Crystallyzer
 *
 * Created on 3 de mayo de 2024, 12:28 AM
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>
#include <cstdlib>
#include "arreglos_genericos.h"

enum Heroe{CODIGO,NOMBRE,ROL,CATEGORIA,PUNTAJE};

using namespace std;

void llenar_arreglo_heroes(void *&arreglo_heroes,int &cantidad_total_heroes,const char *nombArch){
    void **aux,*buff[500],*dato;
    cantidad_total_heroes=0;
    
    ifstream archHeroes(nombArch,ios::in);
    if(!archHeroes){
        cout<<"ERROR: no se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    
    while(1){
        dato=leerHeroes(archHeroes);
        if(dato==nullptr)break;
        buff[cantidad_total_heroes]=dato;
        cantidad_total_heroes++;
    }
    aux=new void *[cantidad_total_heroes+1];
    for(int i=0;i<cantidad_total_heroes;i++)aux[i]=buff[i];
    aux[cantidad_total_heroes]=nullptr;
    
    arreglo_heroes=aux;
}

void *leerHeroes(ifstream &archHeroes){
    void **heroe;
    int aux,*heroeCod;
    char buff[100],*heroeNomb,*heroeRol,*heroeCat,c;
    double *puntaje;
    
    archHeroes>>aux;
    if(archHeroes.eof())return nullptr;
    heroeCod=new int;
    *heroeCod=aux;
    archHeroes>>c;
    archHeroes.getline(buff,100,',');
    heroeNomb=new char[strlen(buff)+1];
    strcpy(heroeNomb,buff);
    archHeroes.getline(buff,100,',');
    heroeRol=new char[strlen(buff)+1];
    strcpy(heroeRol,buff);
    archHeroes.getline(buff,100,',');
    heroeCat=new char[strlen(buff)+1];
    strcpy(heroeCat,buff);
    puntaje=new double;
    archHeroes>>*puntaje;
    
    heroe=new void*[5];
    heroe[CODIGO]=heroeCod;
    heroe[NOMBRE]=heroeNomb;
    heroe[ROL]=heroeRol;
    heroe[CATEGORIA]=heroeCat;
    heroe[PUNTAJE]=puntaje;
    
    return heroe;
}

int cmp_multicriterio_void(const void *datoI,const void *datoJ){
    void **datoI2=(void **)datoI,
         **datoJ2=(void **)datoJ;
    
    void **dato1=(void **)(datoI2[0]),
         **dato2=(void **)(datoJ2[0]);
    char *nomb1=(char *)(dato1[NOMBRE]),
         *nomb2=(char *)(dato2[NOMBRE]);
    double *puntaje1=(double *)(dato1[PUNTAJE]),
           *puntaje2=(double *)(dato2[PUNTAJE]);
    
    if(strcmp(nomb1,nomb2)==0)return *puntaje2-*puntaje1;
    else return strcmp(nomb1,nomb2);
}

/*void imprimirArreglo(void *arreglo_heroes,int cantidad_total_heroes){
    void **arr=(void **)arreglo_heroes;
    for(int i=0;i<cantidad_total_heroes;i++)imprimirHeroe(arr[i]);
}

void imprimirHeroe(void *arreglo_heroes){
    void **arr=(void **)arreglo_heroes;
    char *nombre=(char *)arr[NOMBRE];
    double *puntaje=(double *)arr[PUNTAJE];
    
    cout<<nombre<<" "<<*puntaje<<endl;
}*/