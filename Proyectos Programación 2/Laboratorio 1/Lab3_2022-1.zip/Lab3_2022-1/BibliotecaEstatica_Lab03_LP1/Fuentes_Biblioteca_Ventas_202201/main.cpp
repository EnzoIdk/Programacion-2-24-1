/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Enzo
 *
 * Created on 24 de marzo de 2024, 10:09 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>        

using namespace std;

#include "AperturaDeArchivos.h"
#include "Estruturas.h"
#include "Ventas_LP1_202201.h"
int main(int argc, char** argv) {
    
    ifstream archClientes;
    ofstream archReporte;
    struct Estructura_ClienteRegistrado c1,c2;
    AperturaDeUnArchivoDeTextosParaLeer(archClientes,"clientes.txt");
    return 0;
}

