/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Ventas_LP1_202201.h
 * Author: Enzo
 *
 * Created on 25 de marzo de 2024, 12:04 AM
 */

#ifndef VENTAS_LP1_202201_H
#define VENTAS_LP1_202201_H



#endif /* VENTAS_LP1_202201_H */

