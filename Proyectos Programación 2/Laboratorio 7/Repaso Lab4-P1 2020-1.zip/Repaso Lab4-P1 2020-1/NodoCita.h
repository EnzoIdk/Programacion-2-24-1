/* 
 * File:   NodoCita.h
 * Author: Lucas
 *
 * Created on 31 de mayo de 2024, 19:55
 */

#ifndef NODOCITA_H
#define NODOCITA_H

struct NodoCita{
    int horario;
    char estado[20];
};

#endif /* NODOCITA_H */

