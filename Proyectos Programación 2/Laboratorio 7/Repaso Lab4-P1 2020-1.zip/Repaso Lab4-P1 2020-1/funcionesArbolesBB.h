/* 
 * File:   funcionesArbolesBB.h
 * Author: ANA RONCAL
 * Created on 24 de septiembre de 2023, 10:34 PM
 */

#ifndef FUNCIONESARBOLESBB_H
#define FUNCIONESARBOLESBB_H


void recorrerEnOrdenRecursivo(struct Nodo * nodo);
void imprimeNodo(struct Nodo * nodo);

void insertar(struct ArbolBB & arbol, NodoCita elemento);
void insertarRecursivo(struct Nodo *& nodo, NodoCita elemento);
void eliminar(struct ArbolBB arbol, NodoCita elemento);
struct Nodo * eliminarRecursivo(struct Nodo * nodo, NodoCita elemento);
struct Nodo * minimoNodo(struct Nodo * nodo);

void construir(struct ArbolBinarioBusqueda & arbol);
bool esArbolVacio(const struct ArbolBinarioBusqueda & arbol);

void plantarArbolBB(struct NodoArbol *& arbol, 
                    struct NodoArbol * arbolIzquierdo, NodoCita elemento, 
                    struct NodoArbol * arbolDerecho);

void preOrden(const struct ArbolBinarioBusqueda & arbol);
void enOrden(const struct ArbolBinarioBusqueda & arbol);
void postOrden(const struct ArbolBinarioBusqueda & arbol);
void destruirArbolBB(struct ArbolBinarioBusqueda & arbol);

void insertar(struct ArbolBinarioBusqueda & arbol, NodoCita elemento);

int minimoNodoABB(const struct ArbolBinarioBusqueda &);
int maximoNodoABB(const struct ArbolBinarioBusqueda &);

struct NodoArbol *  minimoArbol(struct NodoArbol * nodo);
bool buscaArbol(const struct ArbolBinarioBusqueda & arbol ,NodoCita dato);
void eliminarNodo(struct ArbolBinarioBusqueda & ,NodoCita );
int comparaABB(int, int); 
int sumarNodos(const struct ArbolBinarioBusqueda & arbol);

void insertarRecursivo(struct NodoArbol *& raiz, NodoCita elemento);
int minimoNodo(struct NodoArbol * nodo);
int maximoNodo(struct NodoArbol * nodo);
bool buscaArbolRecursivo(struct NodoArbol * nodo, NodoCita dato);
struct NodoArbol * eliminarNodoRecursivo(struct NodoArbol * nodo, NodoCita elemento);

#endif /* FUNCIONESARBOLESBB_H */

