/* 
 * File:   main.cpp
 * Author: Lucas
 *
 * Created on 31 de mayo de 2024, 19:41
 */

#include <iostream>
using namespace std;
#include <cstring>

#include "ArbolBinarioBusqueda.h"
#include "funcionesArbolesBB.h"
#include "funcionesArbolesBinarios.h"

/*
 * 8 a 18 - 10 horas
 * L 1 - M 2 - X 3 - J 4 - V 5
 */

struct NodoArbol * buscarNodo(struct NodoArbol * parbol, NodoCita dato){
    if(parbol==nullptr) return nullptr;
    if(dato.horario>parbol->elemento.horario) 
        return buscarNodo(parbol->derecha, dato);
    else if(dato.horario<parbol->elemento.horario) 
        return buscarNodo(parbol->izquierda, dato);
    else return parbol;
}

void verificarHorario(struct ArbolBinarioBusqueda &abb, NodoCita dato){
    bool ocupado=buscaArbol(abb, dato);
    if(ocupado) cout<<"Horario no disponible"<<endl;
    else{
        cout<<"Disponible"<<endl;
        insertar(abb, dato);
    }
}

void copiaEstado(struct NodoArbol * parbol, char * estado){
    strcpy(parbol->elemento.estado, estado);
}

void actualizaEstados(struct NodoArbol * parbol, NodoCita dato){
    if(parbol==nullptr){
        cout<<"No se encuentra el horario"<<endl;
        return;
    }
    if(comparaABB(parbol->elemento.horario, dato.horario)==0){
        copiaEstado(parbol, dato.estado);
        return;
    }
    if(comparaABB(parbol->elemento.horario, dato.horario)==-1){
        return actualizaEstados(parbol->derecha, dato);
    }
    if(comparaABB(parbol->elemento.horario, dato.horario)==1){
        return actualizaEstados(parbol->izquierda, dato);
    }
}

int main(int argc, char** argv) {
    
    struct ArbolBinarioBusqueda abb;
    construir(abb);
    
    //CITAS PREVIAS
    insertar(abb, {1*100+14});
    insertar(abb, {1*100+12});
    insertar(abb, {2*100+10});
    insertar(abb, {2*100+18});
    insertar(abb, {3*100+11});
    insertar(abb, {4*100+12});
    insertar(abb, {5*100+10});
    insertar(abb, {5*100+17});
    
    recorrerEnOrden(abb.arbolBinario); cout<<endl;
    
    verificarHorario(abb, {4*100+13});
    
    char llego[20]="Llego", tarde[20]="Tarde", falta[20]="Falta";
    
    struct NodoCita temp;
    
    strcpy(temp.estado, llego);
    temp.horario=1*100+14;
    actualizaEstados(abb.arbolBinario.raiz, temp);//tiempo
    
    strcpy(temp.estado, tarde);
    temp.horario=2*100+10;
    actualizaEstados(abb.arbolBinario.raiz, temp);//retraso
    
    strcpy(temp.estado, llego);
    temp.horario=3*100+11;
    actualizaEstados(abb.arbolBinario.raiz, temp);//falta
    
    strcpy(temp.estado, llego);
    temp.horario=1*100+16;
    actualizaEstados(abb.arbolBinario.raiz, temp);
    
    strcpy(temp.estado, llego);
    temp.horario=5*100+17;
    actualizaEstados(abb.arbolBinario.raiz, temp);
    
    recorrerEnOrden(abb.arbolBinario);
    
    return 0;
}

