/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funcionesGenercias.h
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 2 de mayo de 2024, 11:15
 */

#ifndef FUNCIONESGENERCIAS_H
#define FUNCIONESGENERCIAS_H

#include <fstream>
using namespace std;

void construir(ifstream &arch, void *&pila,void*(*leenumero)(ifstream &arch), void (*crearPila)(void*, void*&));
void  mostrar(ofstream &arch, void *pila, void(*muestraNumero)(void*, ofstream &arch));
void combinarPilaCola(void *&nueva,void *&cola, void*&pila, int(*cmpnumero)(void*, void*),
        void*(*desapilar)(void*&),  void*(*desencolar)(void*&),void (*crearCola)(void*, void*&) );
#endif /* FUNCIONESGENERCIAS_H */

