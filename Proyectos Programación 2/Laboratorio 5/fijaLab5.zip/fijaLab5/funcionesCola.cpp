/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
enum Nodo{
    VALOR, SIGUIENTE
};
enum Cabeza{
    INICIO, FIN,LONGITUD
};
void  crearCola(void*numero, void*&cola){
    void **nuevo=new void*[2]{};
    nuevo[VALOR]= numero;
    if (cola==nullptr){
        void**cabeza=new void*[3]{};
        int *longi=new int;
        *longi=1;
          cabeza[LONGITUD]=longi;
          cabeza[INICIO]=nuevo;
          cabeza[FIN]=nuevo;
          cola=cabeza;
    }else{
         void**cabeza=(void**)cola;
         void**ultimo=(void**)cabeza[FIN];
         ultimo[SIGUIENTE]=nuevo;
         cabeza[FIN]=nuevo;
         (*(int*)  cabeza[LONGITUD])++;
    }
}