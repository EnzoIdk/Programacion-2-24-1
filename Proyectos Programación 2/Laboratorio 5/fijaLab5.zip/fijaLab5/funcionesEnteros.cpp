/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
enum CabezaP{
    PILA, LONGITUD
};
enum Nodo{
    VALOR, SIGUIENTE
};
enum CabezaC{
    INICIO, FIN
};
void *leenumero(ifstream&arch){
    int nu,*numero=new int;
    arch>>nu;
    *numero=nu;
    return numero;
}
 void muestraNumero(void*numero, ofstream &arch){
     int *num=(int*)numero;
     arch<<*num<<endl;
}
 int cmpnumero(void *valorP , void *valorC){
    int *p=(int*)valorP;
    int *c=(int*)valorC;
    return *p-*c;
}
 void *desapilarEnteros(void *&pila){
     void **cabezaP=(void**)pila;
    void **recorridoP=(void**)cabezaP[PILA];
    cabezaP[PILA]=recorridoP[SIGUIENTE];
    int *eliminar=(int*)recorridoP[VALOR];
    int numero=*(int*)recorridoP[VALOR];
    int *ptr=new int ;
    *ptr=numero;
    delete eliminar;
    delete recorridoP;
    return ptr;
}
 void *desencolarEnteros(void *&cola){
     void **cabezaP=(void**)cola;
    void **recorridoP=(void**)cabezaP[INICIO];
    cabezaP[INICIO]=recorridoP[SIGUIENTE];
     int *eliminar=(int*)recorridoP[VALOR];
     int numero=*(int*)recorridoP[VALOR];
     int *ptr=new int ;
    *ptr=numero;
     delete eliminar;
    delete recorridoP;
    return ptr;
}
