/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
enum CabezaP{
    PILA, LONGITUD
};
enum Nodo{
    VALOR, SIGUIENTE
};
enum CabezaC{
    INICIO, FIN
};
void construir(ifstream &arch, void *&pila,void*(*leenumero)(ifstream &arch), void (*crearPila)(void*, void*&)){
    void *numero;
    pila=nullptr;
    while(true){
        numero=leenumero(arch);
        if (arch.eof()) break;
        crearPila(numero, pila);
    }
}
void  mostrar(ofstream &arch, void *pila, void(*muestraNumero)(void*, ofstream &arch)){
    void **cabeza=(void**)pila;
    void **recorrido=(void**)cabeza[PILA];
    while(recorrido){
        muestraNumero(recorrido[VALOR], arch);
        recorrido=(void**)recorrido[SIGUIENTE];
    }
}
void combinarPilaCola(void *&nueva,void *&cola, void*&pila, int(*cmpnumero)(void*, void*),
        void*(*desapilar)(void*&),  void*(*desencolar)(void*&),void (*crearCola)(void*, void*&) ){
    void **cabezaP=(void**)pila;
    void **cabezaC=(void**)cola;
    void **recorridoP=(void**)cabezaP[PILA];
    void **recorridoC=(void**)cabezaC[INICIO];
    
    void*valorP, *valorC;
    nueva=nullptr;
    while(recorridoP and recorridoC ){//si uno de ellos se termina, todo habrá acabado
        valorP=desapilar(pila);
        valorC=desencolar(cola);
        if (cmpnumero(valorP , valorC)==0){
            crearCola(valorP,nueva );
//            crearCola(valorC,cola );//se está volvindo a encolar
        }else if (cmpnumero(valorP , valorC)<0){
            crearCola(valorP,nueva );
            crearCola(valorC,nueva );
        }else{
            crearCola(valorC,nueva );
            crearCola(valorP,nueva );
        }
        recorridoP=(void**)recorridoP[SIGUIENTE];
        recorridoC=(void**)recorridoC[SIGUIENTE];
    }
}

