/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funcionesEnteros.h
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 2 de mayo de 2024, 11:20
 */

#ifndef FUNCIONESENTEROS_H
#define FUNCIONESENTEROS_H

#include <fstream>
using namespace std;

void *leenumero(ifstream&arch);
 void muestraNumero(void*numero, ofstream &arch);
  int cmpnumero(void *valorP , void *valorC);
   void *desapilarEnteros(void *&pila);
    void *desencolarEnteros(void *&cola);
#endif /* FUNCIONESENTEROS_H */

