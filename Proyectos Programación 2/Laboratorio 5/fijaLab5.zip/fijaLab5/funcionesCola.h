/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funcionesCola.h
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 2 de mayo de 2024, 11:32
 */

#ifndef FUNCIONESCOLA_H
#define FUNCIONESCOLA_H

#include <fstream>
using namespace std;

void  crearCola(void*numero, void*&cola);
#endif /* FUNCIONESCOLA_H */

