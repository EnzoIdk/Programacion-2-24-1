/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
enum Nodo{
    VALOR, SIGUIENTE
};
enum CabezaP{
    PILA, LONGITUD
};

void  crearPila(void*numero, void*&pila){
    void**nuevo=new void*[2]{};
    nuevo[VALOR]=numero;
    if (pila==nullptr){//la pila esta vacía
        void**cabeza=new void*[2]{};
        cabeza[PILA]=nuevo;
        int longi=0, *ptr=new int;
        *ptr=1;
        cabeza[LONGITUD]=ptr;
        pila=cabeza;
    }else{
        void**cabeza=(void**)pila;
        nuevo[SIGUIENTE]= cabeza[PILA];
         cabeza[PILA]=nuevo;
          (*(int*)cabeza[LONGITUD])++;
    }
    
}