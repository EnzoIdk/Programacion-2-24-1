/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funcionesPila.h
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 2 de mayo de 2024, 11:19
 */

#ifndef FUNCIONESPILA_H
#define FUNCIONESPILA_H

#include <fstream>
using namespace std;

void  crearPila(void*numero, void*&pila);


#endif /* FUNCIONESPILA_H */

