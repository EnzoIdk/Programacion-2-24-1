/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 2 de mayo de 2024, 10:51
 */

#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;
#include "funcionesEnteros.h"
#include "funcionesGenericas.h"
#include "funcionesPila.h"
#include "funcionesCola.h"
/*
 * iniciali<aer
 */
int main(int argc, char** argv) {

    ifstream archPila("pila.txt", ios::in);
    if(not archPila.is_open()){
        cout<<"error con la apertura del archivo: "<<"pila"<<endl;
    }
    ofstream archMuestraPila("mostrarPila.txt", ios::out);
    if(not archPila.is_open()){
        cout<<"error con la impresion del archivo: "<<"pila"<<endl;
    }
    ifstream archCola("cola.txt", ios::in);
    if(not archCola.is_open()){
        cout<<"error con la apertura del archivo: "<<"cola"<<endl;
    }
        ofstream archMuestraCola("mostrarCola.txt", ios::out);
    if(not archPila.is_open()){
        cout<<"error con la impresion del archivo: "<<"cola"<<endl;
    }
        ofstream archNueva("nuevaCola.txt", ios::out);
    if(not archNueva.is_open()){
        cout<<"error con la impresion del archivo: "<<"cola"<<endl;
    }
        ofstream archActual("actualCola.txt", ios::out);
    if(not archActual.is_open()){
        cout<<"error con la impresion del archivo: "<<"cola"<<endl;
    }
    void *pila;
    construir(archPila, pila,leenumero, crearPila);
    mostrar(archMuestraPila, pila, muestraNumero);
    void*cola;
    construir(archCola, cola,leenumero, crearCola);
    mostrar(archMuestraCola, cola, muestraNumero);
    void*nuevaCola;
    combinarPilaCola(nuevaCola,cola, pila,cmpnumero,desapilarEnteros,desencolarEnteros,crearCola );
    mostrar(archNueva, nuevaCola, muestraNumero);
//      mostrar(archActual, cola, muestraNumero);
    return 0;
}

