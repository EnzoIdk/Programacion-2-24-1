/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funclista.h
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 1 de mayo de 2024, 15:01
 */

#ifndef FUNCLISTA_H
#define FUNCLISTA_H

#include <fstream>
using namespace std;

void  construirLista(void *dato, void *&cima);
#endif /* FUNCLISTA_H */

