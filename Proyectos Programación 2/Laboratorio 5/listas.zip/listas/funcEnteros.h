/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funcEnteros.h
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 1 de mayo de 2024, 15:01
 */

#ifndef FUNCENTEROS_H
#define FUNCENTEROS_H

#include <fstream>
using namespace std;
void* leeEntero(ifstream &arch);
void  imprimEntero(ofstream &arch, void *dato);
#endif /* FUNCENTEROS_H */

