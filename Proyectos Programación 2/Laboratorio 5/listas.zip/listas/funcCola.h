/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funcCola.h
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 1 de mayo de 2024, 17:07
 */

#ifndef FUNCCOLA_H
#define FUNCCOLA_H

#include <fstream>
using namespace std;

void  construirCola(void *dato, void *&cola);
int cmpCola(const void*a, const void*b);
#endif /* FUNCCOLA_H */

