/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   lsitaDoble.h
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 1 de mayo de 2024, 15:30
 */

#ifndef LSITADOBLE_H
#define LSITADOBLE_H

#include <fstream>
using namespace std;

void  cosntruirDobleAtras(void *dato, void *&lista);
#endif /* LSITADOBLE_H */

