/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   PilaConRegistros.h
 * Author: user
 *
 * Created on 2 de mayo de 2024, 16:57
 */

#ifndef PILACONREGISTROS_H
#define PILACONREGISTROS_H
#include <fstream>
using namespace std;


#endif /* PILACONREGISTROS_H */

