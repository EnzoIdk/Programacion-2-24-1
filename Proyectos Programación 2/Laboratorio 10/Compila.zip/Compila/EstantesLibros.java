/**
 *
 * @author cueva
 */
public class EstantesLibros {
    public static void main(String[] args) {

        Biblioteca bli;
        
        bli = new Biblioteca();
        
        bli.carga();
        bli.imprime();
        
        
    }
    
}
