/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   MovimientosEnTablero.h
 * Author: alulab14
 *
 * Created on 5 de junio de 2024, 11:58 AM
 */

#ifndef MOVIMIENTOSENTABLERO_H
#define MOVIMIENTOSENTABLERO_H
#include "Tablero.h"
class MovimientosEnTablero {
public:
    void cargar_Y_MoverFichas(const char*,const char*,const char*);
private:
    class Tablero tablero;
};

#endif /* MOVIMIENTOSENTABLERO_H */
    
