/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Nodo.cpp
 * Author: Enzo
 * 
 * Created on 11 de junio de 2024, 09:43 PM
 */

#include "Nodo.h"

Nodo::Nodo() {
    izq=nullptr;
    der=nullptr;
}


