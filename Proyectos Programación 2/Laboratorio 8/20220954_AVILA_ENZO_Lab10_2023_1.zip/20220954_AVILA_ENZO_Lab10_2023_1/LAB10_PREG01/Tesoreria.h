/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Tesoreria.h
 * Author: Enzo
 *
 * Created on 12 de junio de 2024, 12:30 AM
 */

#ifndef TESORERIA_H
#define TESORERIA_H
#include "Arbol.h"
class Tesoreria {
private:
    class Arbol aboleta;
public:
    void cargaalumnos();
    void imprimeboleta();
};

#endif /* TESORERIA_H */

