/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   NodoPaciente.cpp
 * Author: Enzo
 * 
 * Created on 13 de junio de 2024, 10:57 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "NodoPaciente.h"

NodoPaciente::NodoPaciente() {
    ptrPaciente=nullptr;
    sig=nullptr;
}

