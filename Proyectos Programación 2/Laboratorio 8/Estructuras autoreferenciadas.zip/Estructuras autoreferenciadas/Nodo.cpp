/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Nodo.cpp
 * Author: aml
 * 
 * Created on 4 de junio de 2024, 08:29 AM
 */

#include "Nodo.h"

Nodo::Nodo() {
    siguiente=nullptr;
}

