/* 
 * File:   Nodo.cpp
 * Author: Lucas
 * 
 * Created on 8 de junio de 2024, 20:59
 */

#include <iostream>
using namespace std;
#include <cstring>

#include "Nodo.h"

//CONST Y DEST
Nodo::Nodo() {
    siguiente=nullptr;
}

//GETTERS Y SETTERS


//METODOS


//FUNCIONES
